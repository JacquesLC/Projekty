﻿using System;
using System.Collections.Generic;
using System.Text;

namespace c44
{
    class Fruit_Based : IceCream
    {
        private bool waffle;
        private string Top_Flavor;
        public Fruit_Based(/*double _price, string _flavor, bool _waffle, string _top_flavor*/)/* :base(_price, _flavor)*/
        {
            //waffle = _waffle;
            //Top_Flavor = _top_flavor;
        }
    }
}
