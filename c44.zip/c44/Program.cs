﻿using System;
using System.Collections.Generic;

namespace c44
{
    class Program
    {
        static void Main(string[] args)
        {
            IceCreamFactory_Algida iceCreamFactory_Algida = new IceCreamFactory_Algida();
            IceCreamFactory_Koral iceCreamFactory_Koral = new IceCreamFactory_Koral();

            IceCreamShop IceCreamShop = new IceCreamShop();

            IceCreamShop.IceCreamFactory = iceCreamFactory_Algida; 
            Console.WriteLine(IceCreamShop.AdvertiseDailySpecial(WeekDay.Monday));
            Console.WriteLine(IceCreamShop.AdvertiseDailySpecial(WeekDay.Tuesday));
            Console.WriteLine(IceCreamShop.AdvertiseDailySpecial(WeekDay.Wednesday));

            //Koral
            IceCreamShop.IceCreamFactory = iceCreamFactory_Koral;

            Console.WriteLine(IceCreamShop.AdvertiseDailySpecial(WeekDay.Thursday));
            Console.WriteLine(IceCreamShop.AdvertiseDailySpecial(WeekDay.Friday));


        }
    }
}
