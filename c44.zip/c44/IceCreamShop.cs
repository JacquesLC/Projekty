﻿using System;
using System.Collections.Generic;
using System.Text;

namespace c44
{
    class IceCreamShop
    {
        IceCreamFactory iceCreamFactory;
        public IceCreamFactory IceCreamFactory
        {
            set { iceCreamFactory = value; }
        }

        public string AdvertiseDailySpecial(WeekDay day)
        {
            if (iceCreamFactory.DailySpecial(day).GetType() == new Gelato().GetType())
            {
                return "Daily special: Gelato";
            }
            else if (iceCreamFactory.DailySpecial(day).GetType() == new Regular().GetType())
            {
                return "Daily special: Regular";
            }
            else if (iceCreamFactory.DailySpecial(day).GetType() == new Sorbet().GetType())
            {
                return "Daily special: Sorbet";
            }
            else if (iceCreamFactory.DailySpecial(day).GetType() == new Fruit_Based().GetType())
            {
                return "Daily special: Fruit_Based";
            }
            else
                return null;
        }
    }
}
