﻿using System;
using System.Collections.Generic;
using System.Text;

namespace c44
{
    class Regular : IceCream
    {
        private bool waffle;
        private string Top_Flavor;
        private bool Chocolate_Sprinkles;
        public Regular(/*double _price, string _flavor, bool _waffle, string _top_flavor, bool _chocolate_Sprinkles*/) /*: base(_price, _flavor)*/
        {
            //waffle = _waffle;
            //Top_Flavor = _top_flavor;
            //Chocolate_Sprinkles = _chocolate_Sprinkles;
        }
    }
}
