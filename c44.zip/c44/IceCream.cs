﻿using System;
using System.Collections.Generic;
using System.Text;

namespace c44
{
    class IceCream
    {
        private double price;
        private string flavor;
        public string Flavor
        {
            get { return flavor; }
            set
            {
                flavor = value;
            }
        }
        public double Price
        {
            get { return price; }
            set
            {
                if (value > 0) price = value;
            }
        }
        public IceCream(/*double _price, string _flavor*/)
        {
            //Price = _price;
            //Flavor = _flavor;
        }

    }
}
