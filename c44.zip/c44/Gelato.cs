﻿using System;
using System.Collections.Generic;
using System.Text;

namespace c44
{
    class Gelato : IceCream
    {
        private bool waffle;
        private bool Chocolate_Sprinkles;

        public Gelato(/*double _price, string _flavor, bool _waffle, bool _chocolate_Sprinkles) : base(_price, _flavor*/)
        {            //waffle = _waffle;
            //Chocolate_Sprinkles = _chocolate_Sprinkles;

        }
    }
}
