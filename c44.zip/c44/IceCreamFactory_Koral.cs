﻿using System;
using System.Collections.Generic;
using System.Text;

namespace c44
{
    class IceCreamFactory_Koral : IceCreamFactory
    {
        public override IceCream DailySpecial(WeekDay day)
        {
            if (day == WeekDay.Monday)
            {
                return new Regular();
            }
            else if (day == WeekDay.Tuesday)
            {
                return new Gelato();
            }
            else if (day == WeekDay.Wednesday)
            {
                return new Gelato();
            }
            else if (day == WeekDay.Thursday)
            {
                return new Sorbet();
            }
            else if (day == WeekDay.Friday)
            {
                return new Regular(); ;
            }
            else if (day == WeekDay.Saturday)
            {
                return new Fruit_Based();
            }
            else if (day == WeekDay.Sunday)
            {
                return new Sorbet();
            }
            return new Regular(); ;
        }
    }
}
