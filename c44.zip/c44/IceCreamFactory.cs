﻿using System;
using System.Collections.Generic;
using System.Text;


namespace c44
{
    public enum WeekDay
    {
        Monday,
        Tuesday,
        Wednesday,
        Thursday,
        Friday,
        Saturday,
        Sunday,
    }
    abstract class IceCreamFactory
    {
        
        public abstract IceCream DailySpecial(WeekDay day);

    }
}
