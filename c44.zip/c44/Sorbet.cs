﻿using System;
using System.Collections.Generic;
using System.Text;

namespace c44
{
    class Sorbet : IceCream
    {
        public Sorbet(/*double _price, string _flavor) : base(_price, _flavor*/)
        {
        }
    }
}
